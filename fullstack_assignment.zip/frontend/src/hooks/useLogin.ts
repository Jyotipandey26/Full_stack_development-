import { useMutation } from 'react-query';
import api from '../api/api';
import { LoginFormInputs } from '../lib/zodSchemas';

const useLogin = () => {
  return useMutation((data: LoginFormInputs) => api.post('/login', data));
};

export default useLogin;
