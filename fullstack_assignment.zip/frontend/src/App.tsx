import { QueryClient, QueryClientProvider } from 'react-query';
import LoginForm from './components/LoginForm';

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="App">
        <LoginForm />
      </div>
    </QueryClientProvider>
  );
}

export default App;
